---
allowed-tools: Bash(uv run devspec monitor:*)
description: Run DevSpec consistency monitor and generate dashboard
---
# DevSpec Monitor

Run the consistency check to verify alignment between PRD (Markdown) and SpecGraph (YAML).

**Usage**
! uv run devspec monitor $ARGUMENTS
