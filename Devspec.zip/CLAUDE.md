<!-- DEVSPEC:START -->
# DevSpec Instructions

These instructions are for AI assistants working in this project.

Always open `.specgraph/AGENT.md`

<!-- DevSpec:END -->
