def main():
    print("Hello from devspec!")


if __name__ == "__main__":
    main()
